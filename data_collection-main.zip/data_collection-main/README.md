EnergyProductionYearS.ipynb --> Create a csv file of energy info from api with the ability to select specific days.
EnergyProduction_CSV.ipynb --> Stater made to pull by years set to 5 years.
EnergytodayTEN.ipynb --> Gets today's energy info from API
EnergyProductionFinal.ipynb --> Final version for creating csv with data
Databasepcins --> collects only the last 2 months and uploads to the database on was. 
DatabaseUPM ---> It is the same as databasepcins but is made to work on the ec2 server as a cronjob and has a built-in log file creation.
